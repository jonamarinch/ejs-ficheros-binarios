package CopiarImagen;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;

public class CopiadorImagen {
	
	int[] datos;
	int numDatos;
	String pathFicheroOrigen;
	String pathFicheroDestino;

	public static void main(String[] args) {
		CopiadorImagen copiJava = new CopiadorImagen();
		copiJava.pathFicheroOrigen = "src"+File.separator+"Ficheros"+File.separator+"java-icon.png";
		copiJava.numDatos = copiJava.contarBytes(copiJava.pathFicheroOrigen);
		copiJava.datos = new int[copiJava.numDatos];
		//
		copiJava.rellenarBytes(copiJava.datos, copiJava.pathFicheroOrigen);
		//
		copiJava.pathFicheroDestino = "src"+File.separator+"Ficheros"+File.separator+"java-icon-copia.png";
		
	}
	
	private int contarBytes(String pathFicheroOrigen)
	{	
		int posicionFinal = 0;
		try {
			// Apertura
				FileInputStream lectorBytes = new FileInputStream(new File(pathFicheroOrigen));
			// Lectura
				int valor = lectorBytes.read();
				while (valor != -1)
				{
					posicionFinal++;
					valor = lectorBytes.read();
				}
			// Cierre
				lectorBytes.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return posicionFinal;
	}
	
	private void rellenarBytes(int[] datos, String pathFicheroOrigen)
	{
		int posicion = 0;
		try {
			// Apertura
				FileInputStream lectorBytes = new FileInputStream(new File(pathFicheroOrigen));
			// Lectura
				int valor = lectorBytes.read();
				while (valor != -1)
				{
					valor = lectorBytes.read();
					datos[posicion] = valor;
					posicion++;
				}
			// Cierre
				lectorBytes.close();
		} catch (IOException e) {
				e.printStackTrace();
		}
	}
	
	public void escribirFicheroBinario(String pathFicheroOrigen, String pathFicheroDestino)
	{
		try {
			// Apertura
				FileOutputStream escritorBytes = new FileOutputStream(new File(pathFicheroDestino));
			// Escritura
			// Cierre
		} catch (FileNotFoundException e) {
				e.printStackTrace();
		}
	}

}
