package CopiarImagen;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.File;

public class CopiadorImagen {
	
	// Se guarda la ruta al fichero original, guardado de internet
	private String pathFicheroOrigen;
	// Se guarda la ruta a la copia de aquel fichero original
	private String pathFicheroDestino;

	public static void main(String[] args) {
		// Se crea un objeto de la clase, indicando nombre y extensión del fichero
		CopiadorImagen copiJava = new CopiadorImagen("img", ".jpg");
		// Se hace la copia
		copiJava.escribirFicheroBinario();
		
	}
	
	public CopiadorImagen(String nomImagen, String extImagen)
	{
		this.pathFicheroOrigen = "src"+File.separator+"imagenCopia"+File.separator+nomImagen+extImagen;
		this.pathFicheroDestino = "src"+File.separator+"imagenCopia"+File.separator+nomImagen+" - copia"+extImagen;
	}
	
	private int contarBytes(String pathFicheroOrigen)
	{	
		int posicionFinal = 0;
		try {
			// Apertura
				FileInputStream lectorBytes = new FileInputStream(new File(pathFicheroOrigen));
			// Lectura
				int valor = lectorBytes.read();
				while (valor != -1)
				{
					valor = lectorBytes.read();
					// Se quedará el contador con la última posición
					posicionFinal++;
				}
			// Cierre
				lectorBytes.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return posicionFinal;
	}
	
	private void rellenarBytes(int[] datos, String pathFicheroOrigen)
	{
		int posicion = 0;
		try {
			// Apertura
				FileInputStream lectorBytes = new FileInputStream(new File(pathFicheroOrigen));
			// Lectura
				int valor = lectorBytes.read();
				while (valor != -1)
				{
					// Se va leyendo cada byte y almacenándolo en el vector
					datos[posicion] = valor;
					valor = lectorBytes.read();
					posicion++;
				}
			// Cierre
				lectorBytes.close();
		} catch (IOException e) {
				e.printStackTrace();
		}
	}
	
	private void escribirFicheroBinario()
	{
		try {
			// Apertura
				FileOutputStream escritorBytes = new FileOutputStream(new File(this.pathFicheroDestino));
			// Escritura
				// Se obtiene la cantidad de bytes del fichero a copiar
				int cantidadBytes = this.contarBytes(this.pathFicheroOrigen);
				// Se crea un vector con enteros de ese tamaño exacto
				int[] datos = new int[cantidadBytes];
				// Se rellena el vector con los datos del fichero a copiar
				this.rellenarBytes(datos, this.pathFicheroOrigen);
				// Se va escribiendo la información almacenada en el vector en un nuevo fichero
				for (int i = 0; i < datos.length; i++)
				{
					escritorBytes.write(datos[i]);
				}
			// Cierre
				escritorBytes.close();
		} catch (IOException e) {
				e.printStackTrace();
		}
	}

}
