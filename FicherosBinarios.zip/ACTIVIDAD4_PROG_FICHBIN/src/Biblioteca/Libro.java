package Biblioteca;

public class Libro {
	
	private String titulo;
	private String autor;
	private String annoPub;
	private String[] nomColumnas;
	
	public Libro() {
		this.titulo = "";
		this.autor = "";
		this.annoPub = "0";
		//
		this.nomColumnas = new String[3];
		this.nomColumnas[0] = "Título";
		this.nomColumnas[1] = "Autor";
		this.nomColumnas[2] = "Año";
	}
	
	public Libro(String titulo, String autor, String annoPub) {
		this.titulo = titulo;
		this.autor = autor;
		this.annoPub = annoPub;
		//
		this.nomColumnas = new String[3];
		this.nomColumnas[0] = "Título";
		this.nomColumnas[1] = "Autor";
		this.nomColumnas[2] = "Año";
	}
	
	public static String[] getColumnas()
	{
		String[] nomColumnas = new String[3];
		nomColumnas[0] = "Título";
		nomColumnas[1] = "Autor";
		nomColumnas[2] = "Año";
		return nomColumnas;
	}
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getAnnoPub() {
		return annoPub;
	}
	public void setAnnoPub(String annoPub) {
		this.annoPub = annoPub;
	}
}
