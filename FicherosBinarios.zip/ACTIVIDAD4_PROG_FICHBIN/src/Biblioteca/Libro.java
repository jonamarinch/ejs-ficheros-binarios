package Biblioteca;

import java.io.Serializable;

public class Libro implements Serializable{
	
	// Propiedades del libro
	private String titulo;
	private String autor;
	private String annoPub;
	// Nombres de las columnas para la tabla (lo usaré para crear el objeto de la tabla)
	private String[] nomColumnas;
	
	// Constructor sin parámetros
	public Libro() {
		this.titulo = "";
		this.autor = "";
		this.annoPub = "0";
		//
		this.nomColumnas = new String[3];
		this.nomColumnas[0] = "Título";
		this.nomColumnas[1] = "Autor";
		this.nomColumnas[2] = "Año";
	}
	
	// Constructor parametrizado
	public Libro(String titulo, String autor, String annoPub) {
		this.titulo = titulo;
		this.autor = autor;
		this.annoPub = annoPub;
		//
		this.nomColumnas = new String[3];
		this.nomColumnas[0] = "Título";
		this.nomColumnas[1] = "Autor";
		this.nomColumnas[2] = "Año";
	}
	
	// Nombres de las columnas para la tabla (lo usaré para crear el objeto de la tabla)
	public static String[] getColumnas()
	{
		String[] nomColumnas = new String[3];
		nomColumnas[0] = "Título";
		nomColumnas[1] = "Autor";
		nomColumnas[2] = "Año";
		return nomColumnas;
	}
	
	/*
	 * Getters y Setters
	 */
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getAnnoPub() {
		return annoPub;
	}
	public void setAnnoPub(String annoPub) {
		this.annoPub = annoPub;
	}
	
	// Un método que tan sólo usé para algunas pruebas
	public void mostrarInfo()
	{
		System.out.println(this.titulo + " # " + this.autor + " # " + this.annoPub);
	}
}
