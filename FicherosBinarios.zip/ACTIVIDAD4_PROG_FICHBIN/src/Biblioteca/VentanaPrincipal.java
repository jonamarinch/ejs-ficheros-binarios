package Biblioteca;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.awt.event.ActionEvent;

public class VentanaPrincipal extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private final int NUM_MAX_LIBROS;
	private final int NUM_ATR_LIBROS;
	private JPanel contentPane;
	private static JTable table;
	private static Libro[] libros;
	private static String[][] datosLibros;
	private String[] numColumnas;
	private JButton btnAnnadir;
	private JButton btnGuardar;
	private JButton btnCargar;
	private final String pathFicheroBinario;
	private int arrayLength;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 750);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		this.setTitle("Tu Biblioteca");
		this.NUM_MAX_LIBROS = 10;
		this.NUM_ATR_LIBROS = 3;
		this.libros = new Libro[NUM_MAX_LIBROS];
		this.datosLibros = new String[NUM_MAX_LIBROS][NUM_ATR_LIBROS];
		this.numColumnas = Libro.getColumnas();
		this.pathFicheroBinario = "src"+File.separator+"datosBiblioteca"+File.separator+"ficheroBinario.bin";
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		table = new JTable(datosLibros, numColumnas);
		table.setBounds(67, 135, 750, 500);
		contentPane.add(table);
		
		btnAnnadir = new JButton("Añadir libro");
		btnAnnadir.setBounds(72, 55, 140, 40);
		contentPane.add(btnAnnadir);
		btnAnnadir.addActionListener(this);
		
		btnGuardar = new JButton("Guardar todo");
		btnGuardar.setBounds(372, 55, 140, 40);
		contentPane.add(btnGuardar);
		btnGuardar.addActionListener(this);
		
		btnCargar = new JButton("Cargar biblioteca");
		btnCargar.setBounds(672, 55, 140, 40);
		contentPane.add(btnCargar);
		btnCargar.addActionListener(this);
	}
	
	public static void annadirLibro(String titulo, String autor, String anno)
	{
		int ultimaPosicion = -1;
		
		for (int i = 0; i < 10; i++)
		{
			if (datosLibros[i][0] == null)
			{
				ultimaPosicion = i;
				break;
			}
		}
		
		if (ultimaPosicion == -1)
		{
			JOptionPane.showMessageDialog(null, "Lo siento, ya has completado tu biblioteca. Si quieres, puedes modificar los ejemplares existentes desde la misma tabla.", "No hay espacio", JOptionPane.INFORMATION_MESSAGE);
		}else
		{
			datosLibros[ultimaPosicion][0] = titulo;
			datosLibros[ultimaPosicion][1] = autor;
			datosLibros[ultimaPosicion][2] = anno;
			
			libros[ultimaPosicion] = new Libro(titulo, autor, anno);
		}
	}
	
	public static void actualizarDatosLibros()
	{
		for (int i = 0; i < datosLibros.length; i++)
		{
			for (int l = 0; l < datosLibros[i].length; l++)
			{
				datosLibros[i][l] = "";
			}
		}
		for (int i = 0; i < libros.length; i++)
		{
			if (libros[i] != null)
			{
				datosLibros[i][0] = libros[i].getTitulo();
				datosLibros[i][1] = libros[i].getAutor();
				datosLibros[i][2] = libros[i].getAnnoPub();
			}
		}
	}
	
	public static void actualizarTabla()
	{
		table.repaint();
	}
	
	public static boolean verificarNumString(String num)
	{
		boolean cond = false;
		if (!num.matches("\\d+")) 
		{} 
		else 
		{
			cond = true;
		}
		return cond;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource().equals(btnAnnadir))
		{
			JFrame propietario = new JFrame();
			propietario.setResizable(false);
			Annadir add = new Annadir(this, "Añadir libro");
		}
		else if (e.getSource().equals(btnGuardar))
		{
			File ficheroBinario = new File(this.pathFicheroBinario);
			try {
				// Apertura
				FileOutputStream flujoSalida = new FileOutputStream(ficheroBinario);
				ObjectOutputStream oos = new ObjectOutputStream(flujoSalida);
				// Escritura
				for (int i = 0; i < libros.length; i++)
				{
					oos.writeObject((Libro)libros[i]);
				}
				// Cierre
				flujoSalida.close();
				this.arrayLength = libros.length;
				JOptionPane.showMessageDialog(null, "Se guardó la biblioteca", "Registro guardado", JOptionPane.INFORMATION_MESSAGE);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else if (e.getSource().equals(btnCargar))
		{
			File ficheroBinario = new File(this.pathFicheroBinario);
			try {
				// Apertura
				FileInputStream flujoEntrada = new FileInputStream(ficheroBinario);
				ObjectInputStream ois = new ObjectInputStream(flujoEntrada);
				// Lectura
				for (int i = 0; i < libros.length; i++)
				{
					libros[i] = null;
				}
				Libro unLibro = (Libro)ois.readObject();
				int posLibro = 0;
				while (unLibro != null)
				{
					libros[posLibro] = unLibro;
					unLibro = (Libro)ois.readObject();
					posLibro++;
				}
				// Cierre
				ois.close();
				actualizarDatosLibros();
				actualizarTabla();
				JOptionPane.showMessageDialog(null, "Se han cargado los datos", "Listo", JOptionPane.INFORMATION_MESSAGE);
			} catch(EOFException eof) {
			} catch (IOException e1){
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	
	static class Annadir extends JDialog {

		private static final long serialVersionUID = 1L;
		private final JPanel contentPanel = new JPanel();

		/**
		 * Create the dialog.
		 */
		public Annadir(JFrame propietario, String titulo) {
			super(propietario, titulo);
			setBounds(100, 100, 450, 300);
			getContentPane().setLayout(new BorderLayout());
			contentPanel.setLayout(null);
			contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			getContentPane().add(contentPanel);
			this.setLocationRelativeTo(propietario);
			JTextField jTF1;
			JTextField jTF2;
			JTextField jTF3;
			{
				JPanel jTFPane = new JPanel();
				jTFPane.setLayout(null);
				getContentPane().add(jTFPane, BorderLayout.CENTER);
				{
					JLabel jL1 = new JLabel("Título:");
					jL1.setBounds(3, 0, 150, 30);
					jTFPane.add(jL1);
					//
					jTF1 = new JTextField();
					jTF1.setBounds(3, 35, 200, 30);
					jTFPane.add(jTF1);
					
					JLabel jL2 = new JLabel("Autor:");
					jL2.setBounds(3, 80, 150, 30);
					jTFPane.add(jL2);
					//
					jTF2 = new JTextField();
					jTF2.setBounds(3, 115, 200, 30);
					jTFPane.add(jTF2);
					
					JLabel jL3 = new JLabel("Año:");
					jL3.setBounds(3, 160, 150, 30);
					jTFPane.add(jL3);
					//
					jTF3 = new JTextField();
					jTF3.setBounds(3, 195, 200, 30);
					jTFPane.add(jTF3);
				}
			}
			{
				JPanel buttonPane = new JPanel();
				buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
				getContentPane().add(buttonPane, BorderLayout.SOUTH);
				{
					JButton okButton = new JButton("Añadir libro");
					buttonPane.add(okButton);
					okButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							if (!jTF1.getText().equals("") && !jTF2.getText().equals("") && !jTF3.getText().equals(""))
							{
								if (verificarNumString(jTF3.getText()))
								{
									annadirLibro(jTF1.getText(), jTF2.getText(), jTF3.getText());
									actualizarTabla();
									dispose();
								}
								else
								{
									JOptionPane.showMessageDialog(null, "Debes introducir un número", "Año inválido", JOptionPane.ERROR_MESSAGE);
								}
							}
							else
							{
								JOptionPane.showMessageDialog(null, "Falta algún campo por rellenar", "Rellene todos los campos", JOptionPane.ERROR_MESSAGE);
							}
						}
					});
					getRootPane().setDefaultButton(okButton);
				}
			}
			this.setVisible(true);
		}
	}
}
