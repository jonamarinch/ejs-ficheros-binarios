package Biblioteca;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class VentanaPrincipal extends JFrame implements ActionListener{

	private static final long serialVersionUID = 1L;
	private final int NUM_MAX_LIBROS;
	private final int NUM_ATR_LIBROS;
	private JPanel contentPane;
	private static JTable table;
	private static String[][] libros;
	private String[] numColumnas;
	private JButton btnAnnadir;
	private static DefaultTableModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 900, 750);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setLocationRelativeTo(null);
		this.setTitle("Tu Biblioteca");
		this.NUM_MAX_LIBROS = 10;
		this.NUM_ATR_LIBROS = 3;
		this.libros = new String[NUM_MAX_LIBROS][NUM_ATR_LIBROS];
		this.numColumnas = Libro.getColumnas();
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
//		model = new DefaultTableModel(libros, numColumnas);
		table = new JTable(libros, numColumnas);
		table.setBounds(67, 135, 750, 500);
		contentPane.add(table);
		
		btnAnnadir = new JButton("Añadir libro");
		btnAnnadir.setBounds(72, 55, 140, 40);
		contentPane.add(btnAnnadir);
		btnAnnadir.addActionListener(this);
		
		JButton btnGuardar = new JButton("Guardar todo");
		btnGuardar.setBounds(372, 55, 140, 40);
		contentPane.add(btnGuardar);
		
		JButton btnCargar = new JButton("Cargar biblioteca");
		btnCargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnCargar.setBounds(672, 55, 140, 40);
		contentPane.add(btnCargar);
	}
	
	public static void annadirLibro(String titulo, String autor, String anno)
	{
		int ultimaPosicion = 0;
		
		for (int i = 0; i < 10; i++)
		{
			if (libros[i][0] == null)
			{
				ultimaPosicion = i;
				break;
			}
		}
		
		libros[ultimaPosicion][0] = titulo;
		libros[ultimaPosicion][1] = autor;
		libros[ultimaPosicion][2] = anno;
	}
	
	public static void actualizarTabla()
	{
		table.repaint();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if (e.getSource().equals(btnAnnadir))
		{
			JFrame propietario = new JFrame();
			propietario.setResizable(false);
			Annadir add = new Annadir(this, "Añadir libro");
		}
	}
	
	static class Annadir extends JDialog {

		private static final long serialVersionUID = 1L;
		private final JPanel contentPanel = new JPanel();

		/**
		 * Create the dialog.
		 */
		public Annadir(JFrame propietario, String titulo) {
			super(propietario, titulo);
			setBounds(100, 100, 450, 300);
			getContentPane().setLayout(new BorderLayout());
			contentPanel.setLayout(null);
			contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
			getContentPane().add(contentPanel);
			this.setLocationRelativeTo(propietario);
			JTextField jTF1;
			JTextField jTF2;
			JTextField jTF3;
			{
				JPanel jTFPane = new JPanel();
				jTFPane.setLayout(null);
				getContentPane().add(jTFPane, BorderLayout.CENTER);
				{
					JLabel jL1 = new JLabel("Título:");
					jL1.setBounds(3, 0, 150, 30);
					jTFPane.add(jL1);
					//
					jTF1 = new JTextField();
					jTF1.setBounds(3, 35, 200, 30);
					jTFPane.add(jTF1);
					
					JLabel jL2 = new JLabel("Autor:");
					jL2.setBounds(3, 80, 150, 30);
					jTFPane.add(jL2);
					//
					jTF2 = new JTextField();
					jTF2.setBounds(3, 115, 200, 30);
					jTFPane.add(jTF2);
					
					JLabel jL3 = new JLabel("Año:");
					jL3.setBounds(3, 160, 150, 30);
					jTFPane.add(jL3);
					//
					jTF3 = new JTextField();
					jTF3.setBounds(3, 195, 200, 30);
					jTFPane.add(jTF3);
				}
			}
			{
				JPanel buttonPane = new JPanel();
				buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
				getContentPane().add(buttonPane, BorderLayout.SOUTH);
				{
					JButton okButton = new JButton("Añadir libro");
					buttonPane.add(okButton);
					okButton.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							String titulo = jTF1.getText();
							String autor = jTF2.getText();
							String anno = jTF3.getText();
							//
							annadirLibro(titulo, autor, anno);
							actualizarTabla();
							dispose();
						}
					});
					getRootPane().setDefaultButton(okButton);
				}
			}
			this.setVisible(true);
		}
	}
}
